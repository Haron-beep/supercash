# SuperCash Pro - Backend API v2.0

## الخدمات المجانية المستخدمة
- **Render.com** ← تشغيل الـ API
- **Supabase.com** ← قاعدة بيانات PostgreSQL

---

## خطوات الرفع (مجاناً)

### 1. قاعدة البيانات - Supabase
1. روح على **supabase.com** وأنشئ حساب
2. أنشئ **New Project**
3. من **Settings → Database** انسخ:
   - Host
   - Database name
   - User
   - Password

### 2. رفع الكود - GitHub
```bash
git init
git add .
git commit -m "first commit"
git push
```

### 3. تشغيل الـ API - Render.com
1. روح على **render.com** وأنشئ حساب
2. اضغط **New Web Service**
3. اربط GitHub repository
4. أضف هذه المتغيرات:
```
DB_HOST=xxx.supabase.co
DB_NAME=postgres
DB_USER=postgres
DB_PASSWORD=xxx
DB_PORT=5432
SECRET_KEY=اختر-كلمة-سرية-قوية
ADMIN_SECRET=كلمة-سر-المطور
```
5. اضغط **Deploy**

---

## إضافة متجر جديد لعميل
```
POST /dev/shops/create?secret=ADMIN_SECRET
{
  "shop_code": "SHOP-001",
  "shop_name": "متجر علي",
  "admin_pin": "1234"
}
```

## إضافة كود تفعيل
```
POST /dev/codes/add?secret=ADMIN_SECRET
{
  "code": "PERM-GOLD-AA11",
  "days": 0
}
```

## عرض كل المتاجر
```
GET /dev/shops?secret=ADMIN_SECRET
```

---

## API Endpoints

| المسار | الطريقة | الوصف |
|--------|---------|-------|
| `/` | GET | فحص الحالة |
| `/auth/login` | POST | تسجيل الدخول |
| `/shops/save` | POST | حفظ البيانات |
| `/shops/{code}/data` | GET | تحميل البيانات |
| `/shops/{code}/activate` | POST | تفعيل كود |
| `/dev/shops/create` | POST | إنشاء متجر جديد |
| `/dev/codes/add` | POST | إضافة كود تفعيل |
| `/dev/shops` | GET | عرض كل المتاجر |
| `/dev/codes` | GET | عرض كل الأكواد |
| `/dev/shops/{code}/toggle` | PATCH | تفعيل/إيقاف متجر |
