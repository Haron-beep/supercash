from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel
from typing import Optional
import psycopg2
import psycopg2.extras
import hashlib
import jwt
import os
from datetime import datetime, timedelta

# ============================================================
#  إعداد التطبيق
# ============================================================
app = FastAPI(title="SuperCash Pro API", version="2.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

SECRET_KEY = os.getenv("SECRET_KEY", "supercash-2024-secret")
ADMIN_SECRET = os.getenv("ADMIN_SECRET", "dev-admin-2024")
security = HTTPBearer()

# ============================================================
#  قاعدة البيانات
# ============================================================
def get_db():
    return psycopg2.connect(
        host=os.getenv("DB_HOST", "localhost"),
        database=os.getenv("DB_NAME", "supercash"),
        user=os.getenv("DB_USER", "postgres"),
        password=os.getenv("DB_PASSWORD", "password"),
        port=os.getenv("DB_PORT", "5432")
    )

def init_db():
    conn = get_db()
    conn.autocommit = True
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS shops (
            id SERIAL PRIMARY KEY,
            shop_code VARCHAR(50) UNIQUE NOT NULL,
            shop_name VARCHAR(100),
            admin_pin VARCHAR(255) NOT NULL,
            data JSONB DEFAULT '{}',
            is_active BOOLEAN DEFAULT TRUE,
            license_status VARCHAR(20) DEFAULT 'trial',
            license_end DATE,
            created_at TIMESTAMP DEFAULT NOW(),
            updated_at TIMESTAMP DEFAULT NOW()
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS activation_codes (
            id SERIAL PRIMARY KEY,
            code VARCHAR(50) UNIQUE NOT NULL,
            days INTEGER NOT NULL,
            used BOOLEAN DEFAULT FALSE,
            used_by VARCHAR(50),
            used_at TIMESTAMP,
            created_at TIMESTAMP DEFAULT NOW()
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS sessions (
            id SERIAL PRIMARY KEY,
            shop_code VARCHAR(50),
            role VARCHAR(20),
            created_at TIMESTAMP DEFAULT NOW()
        )
    """)
    conn.close()
    print("✅ قاعدة البيانات جاهزة")

# ============================================================
#  المساعدات
# ============================================================
def hash_pin(pin: str) -> str:
    return hashlib.sha256(pin.encode()).hexdigest()

def make_token(shop_code: str, role: str) -> str:
    exp = datetime.utcnow() + timedelta(hours=12)
    return jwt.encode(
        {"shop_code": shop_code, "role": role, "exp": exp},
        SECRET_KEY, algorithm="HS256"
    )

def verify_token(creds: HTTPAuthorizationCredentials = Depends(security)):
    try:
        return jwt.decode(creds.credentials, SECRET_KEY, algorithms=["HS256"])
    except jwt.ExpiredSignatureError:
        raise HTTPException(401, "انتهت الجلسة — سجّل دخولك مجدداً")
    except:
        raise HTTPException(401, "رمز غير صالح")

# ============================================================
#  النماذج
# ============================================================
class LoginReq(BaseModel):
    shop_code: str
    pin: str
    role: str = "admin"

class SaveDataReq(BaseModel):
    shop_code: str
    data: dict

class CreateShopReq(BaseModel):
    shop_code: str
    shop_name: str
    admin_pin: str

class AddCodeReq(BaseModel):
    code: str
    days: int

class ActivateReq(BaseModel):
    code: str

# ============================================================
#  المسارات
# ============================================================

@app.on_event("startup")
def startup(): init_db()

@app.get("/")
def root():
    return {"status": "✅ SuperCash API تعمل", "version": "2.0.0"}

# ----- تسجيل الدخول -----
@app.post("/auth/login")
def login(req: LoginReq):
    conn = get_db()
    cur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    cur.execute("SELECT * FROM shops WHERE shop_code=%s", (req.shop_code,))
    shop = cur.fetchone()
    conn.close()
    
    if not shop:
        raise HTTPException(404, "كود المتجر غير موجود")
    if not shop["is_active"]:
        raise HTTPException(403, "هذا المتجر موقوف")
    if hash_pin(req.pin) != shop["admin_pin"]:
        raise HTTPException(401, "الرقم السري خاطئ")
    
    token = make_token(req.shop_code, req.role)
    return {
        "token": token,
        "role": req.role,
        "shop_name": shop["shop_name"],
        "license_status": shop["license_status"],
        "license_end": str(shop["license_end"]) if shop["license_end"] else None
    }

# ----- حفظ بيانات المتجر -----
@app.post("/shops/save")
def save_data(req: SaveDataReq, token=Depends(verify_token)):
    if token["shop_code"] != req.shop_code:
        raise HTTPException(403, "غير مصرح")
    conn = get_db()
    conn.autocommit = True
    cur = conn.cursor()
    cur.execute(
        "UPDATE shops SET data=%s, updated_at=NOW() WHERE shop_code=%s",
        (psycopg2.extras.Json(req.data), req.shop_code)
    )
    conn.close()
    return {"ok": True, "message": "✅ تم الحفظ"}

# ----- تحميل بيانات المتجر -----
@app.get("/shops/{shop_code}/data")
def load_data(shop_code: str, token=Depends(verify_token)):
    if token["shop_code"] != shop_code:
        raise HTTPException(403, "غير مصرح")
    conn = get_db()
    cur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    cur.execute("SELECT data, updated_at FROM shops WHERE shop_code=%s", (shop_code,))
    shop = cur.fetchone()
    conn.close()
    if not shop:
        raise HTTPException(404, "المتجر غير موجود")
    return {"data": shop["data"], "updated_at": str(shop["updated_at"])}

# ----- تفعيل كود -----
@app.post("/shops/{shop_code}/activate")
def activate(shop_code: str, req: ActivateReq, token=Depends(verify_token)):
    if token["shop_code"] != shop_code:
        raise HTTPException(403, "غير مصرح")
    conn = get_db()
    conn.autocommit = True
    cur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    cur.execute("SELECT * FROM activation_codes WHERE code=%s", (req.code,))
    code = cur.fetchone()
    if not code:
        raise HTTPException(404, "الكود غير موجود")
    if code["used"]:
        raise HTTPException(400, "الكود استُخدم مسبقاً")
    days = code["days"]
    end_date = None if days == 0 else (datetime.now() + timedelta(days=days)).date()
    license_status = "active"
    cur.execute(
        "UPDATE activation_codes SET used=TRUE, used_by=%s, used_at=NOW() WHERE code=%s",
        (shop_code, req.code)
    )
    cur.execute(
        "UPDATE shops SET license_status=%s, license_end=%s WHERE shop_code=%s",
        (license_status, end_date, shop_code)
    )
    conn.close()
    return {"ok": True, "days": days, "permanent": days == 0, "end_date": str(end_date) if end_date else None}

# ============================================================
#  لوحة تحكم المطور (محمية)
# ============================================================

@app.post("/dev/shops/create")
def create_shop(req: CreateShopReq, secret: str):
    if secret != ADMIN_SECRET:
        raise HTTPException(403, "غير مصرح")
    conn = get_db()
    conn.autocommit = True
    cur = conn.cursor()
    try:
        cur.execute(
            "INSERT INTO shops (shop_code, shop_name, admin_pin) VALUES (%s, %s, %s)",
            (req.shop_code, req.shop_name, hash_pin(req.admin_pin))
        )
        conn.close()
        return {"ok": True, "message": f"✅ تم إنشاء المتجر: {req.shop_code}"}
    except psycopg2.errors.UniqueViolation:
        raise HTTPException(400, "كود المتجر موجود مسبقاً")

@app.post("/dev/codes/add")
def add_code(req: AddCodeReq, secret: str):
    if secret != ADMIN_SECRET:
        raise HTTPException(403, "غير مصرح")
    conn = get_db()
    conn.autocommit = True
    cur = conn.cursor()
    try:
        cur.execute("INSERT INTO activation_codes (code, days) VALUES (%s, %s)", (req.code, req.days))
        conn.close()
        return {"ok": True, "message": f"✅ تم إضافة الكود: {req.code}"}
    except psycopg2.errors.UniqueViolation:
        raise HTTPException(400, "الكود موجود مسبقاً")

@app.get("/dev/shops")
def list_shops(secret: str):
    if secret != ADMIN_SECRET:
        raise HTTPException(403, "غير مصرح")
    conn = get_db()
    cur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    cur.execute("SELECT shop_code, shop_name, is_active, license_status, license_end, created_at FROM shops ORDER BY created_at DESC")
    shops = cur.fetchall()
    conn.close()
    return {"shops": [dict(s) for s in shops], "total": len(shops)}

@app.get("/dev/codes")
def list_codes(secret: str):
    if secret != ADMIN_SECRET:
        raise HTTPException(403, "غير مصرح")
    conn = get_db()
    cur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    cur.execute("SELECT * FROM activation_codes ORDER BY created_at DESC")
    codes = cur.fetchall()
    conn.close()
    return {"codes": [dict(c) for c in codes]}

@app.patch("/dev/shops/{shop_code}/toggle")
def toggle_shop(shop_code: str, secret: str):
    if secret != ADMIN_SECRET:
        raise HTTPException(403, "غير مصرح")
    conn = get_db()
    conn.autocommit = True
    cur = conn.cursor()
    cur.execute("UPDATE shops SET is_active = NOT is_active WHERE shop_code=%s", (shop_code,))
    conn.close()
    return {"ok": True, "message": "✅ تم تغيير حالة المتجر"}
